# CarPlay jailbreak bridge adapter

This folder deliberately contains documentation only. CarPlay app admission and custom dashboard rendering on a jailbroken phone may rely on private APIs and version-specific hooks. An unverified hook can boot-loop SpringBoard or crash CarPlay.

Before writing a tweak:
- identify exact iPhone model and iOS build;
- identify the installed bridge and version;
- read its documented integration contract;
- confirm its license and supported app-registration mechanism;
- test in a recoverable environment.

Potential bridge to investigate: https://github.com/pavunato/carsurf

Do not assume an app bundle ID alone makes an app visible in CarPlay.
