import SwiftUI
import WebKit

private enum YTStyle {
    static let background = Color(red: 0.055, green: 0.055, blue: 0.06)
    static let panel = Color(red: 0.12, green: 0.12, blue: 0.13)
    static let red = Color(red: 0.95, green: 0.08, blue: 0.08)
}

struct HomeView: View {
    @State private var query = ""
    @State private var selectedURL = URL(string: "https://m.youtube.com/")!
    @State private var web: WKWebView?
    @State private var loading = false

    private let categories = ["All", "Music", "Gaming", "Cars", "Live", "Mixes"]

    var body: some View {
        VStack(spacing: 0) {
            header
            searchBar
            categoryBar
            ZStack(alignment: .top) {
                YTWebView(url: selectedURL, webView: $web, loading: $loading)
                if loading {
                    ProgressView().tint(YTStyle.red).padding(12)
                }
            }
            bottomBar
        }
        .background(YTStyle.background)
        .foregroundStyle(.white)
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image(systemName: "play.rectangle.fill")
                .font(.system(size: 27, weight: .bold))
                .foregroundStyle(YTStyle.red)
            Text("YouTube")
                .font(.system(size: 22, weight: .bold, design: .rounded))
            Spacer()
            Button {
                web?.reload()
            } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 18, weight: .semibold))
                    .padding(10)
                    .background(YTStyle.panel, in: Circle())
            }
            .accessibilityLabel("Reload")
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    private var searchBar: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField("Search YouTube", text: $query)
                .submitLabel(.search)
                .onSubmit { search() }
                .autocorrectionDisabled()
            Button(action: search) {
                Text("Search")
                    .font(.system(size: 14, weight: .bold))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(YTStyle.red, in: Capsule())
            }
        }
        .padding(10)
        .background(YTStyle.panel, in: RoundedRectangle(cornerRadius: 14))
        .padding(.horizontal, 14)
    }

    private var categoryBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.self) { item in
                    Button {
                        if item == "All" {
                            open("https://m.youtube.com/")
                        } else {
                            query = item
                            search()
                        }
                    } label: {
                        Text(item)
                            .font(.system(size: 13, weight: .semibold))
                            .padding(.horizontal, 13)
                            .padding(.vertical, 8)
                            .background(item == "All" ? Color.white : YTStyle.panel,
                                        in: Capsule())
                            .foregroundStyle(item == "All" ? .black : .white)
                    }
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
        }
    }

    private var bottomBar: some View {
        HStack {
            control("chevron.left", title: "Back") { web?.goBack() }
            Spacer()
            control("house.fill", title: "Home") { open("https://m.youtube.com/") }
            Spacer()
            control("clock.arrow.circlepath", title: "History") { open("https://m.youtube.com/feed/history") }
            Spacer()
            control("play.rectangle", title: "Library") { open("https://m.youtube.com/feed/library") }
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 12)
        .background(YTStyle.panel)
    }

    private func control(_ symbol: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: symbol).font(.system(size: 18, weight: .semibold))
                Text(title).font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(.white)
        }
        .accessibilityLabel(title)
    }

    private func search() {
        let term = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        open("https://m.youtube.com/results?search_query=\(term)")
    }

    private func open(_ value: String) {
        guard let url = URL(string: value) else { return }
        selectedURL = url
        web?.load(URLRequest(url: url))
    }
}

private struct YTWebView: UIViewRepresentable {
    let url: URL
    @Binding var webView: WKWebView?
    @Binding var loading: Bool

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = .all

        let view = WKWebView(frame: .zero, configuration: config)
        view.isOpaque = false
        view.backgroundColor = UIColor(YTStyle.background)
        view.scrollView.backgroundColor = UIColor(YTStyle.background)
        view.navigationDelegate = context.coordinator
        view.load(URLRequest(url: url))
        DispatchQueue.main.async { webView = view }
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        if uiView.url != url {
            uiView.load(URLRequest(url: url))
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(loading: $loading) }

    final class Coordinator: NSObject, WKNavigationDelegate {
        @Binding var loading: Bool
        init(loading: Binding<Bool>) { _loading = loading }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            loading = true
        }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            loading = false
        }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            loading = false
        }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            loading = false
        }
    }
}
