import SwiftUI

@main
struct YouTubeCarPlayApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
                .preferredColorScheme(.dark)
        }
    }
}
