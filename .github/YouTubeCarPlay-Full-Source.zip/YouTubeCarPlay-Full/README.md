# YouTube CarPlay — development starter

This repository contains a Swift iOS app prototype and a jailbreak bridge research scaffold.

## Important status
This is **not a finished or tested CarPlay jailbreak tweak** and is not an installable IPA/DEB. It is a packaged source project. Apple restricts CarPlay app categories and entitlement access; jailbroken-device bridges rely on private APIs and can break between iOS versions. The bridge directory intentionally contains no unverified private-symbol hooks.

## Included
- SwiftUI app shell with dark YouTube-inspired navigation
- Search field and categories
- WebKit-based YouTube mobile front end
- Basic navigation controls
- CarPlay bridge integration notes
- GitHub Actions build workflow
- Debian package metadata template for a future, verified tweak

## Safety
Video viewing and search should only be used while parked. Do not interact with video while driving.

## Build on GitHub (no Mac required)
1. Create a GitHub repository and upload all files, including `.github`.
2. Open Actions → `Build iOS app` → Run workflow.
3. Download the build artifact.

The workflow builds an unsigned app bundle. An unsigned artifact is not directly installable; signing is required.

## CarPlay integration
The app itself does not gain CarPlay eligibility merely by being installed. A separately installed and compatible jailbreak bridge is required. Check the bridge's current support, installation instructions, and exact iOS support before using it:
https://github.com/pavunato/carsurf

Do not install random DEBs or private API hooks from untrusted sources.

## Next engineering milestones
1. Confirm exact device model and iOS version.
2. Build and sign the app.
3. Install and verify on the phone.
4. Verify the chosen bridge works with the exact iOS build.
5. Implement a bridge adapter against that bridge's documented interface.
6. Test CarPlay connection, display behavior, audio, disconnect/reconnect, and parked-only playback.
7. Only then package a rootless DEB if a real tweak is required.
